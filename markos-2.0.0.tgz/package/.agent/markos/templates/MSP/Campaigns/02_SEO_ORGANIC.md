# 🏗️ {{COMPANY_NAME}} - SEO & GEO (Generative Engine Optimization) Infrastructure

<!-- markos-token: MSP -->
> [!NOTE] OVERRIDE PATH: Copy this file to .markos-local/MSP/Campaigns/02_SEO_ORGANIC.md to customize it safely.


**Dependencies:** MIR Content Strategy (`{{MIR_STRATEGY_FILE}}`)
**Assigned Agent:** `{{LEAD_AGENT}}` (markos-strategist, markos-content-creator)
**Linear Project Manager:** `markos-linear-manager`

## Core Organic Parameters
- **Primary Keyword Target:** `{{PRIMARY_KEYWORD}}`
- **Domain Authority (DA) Goal:** `{{DOMAIN_AUTHORITY_TARGET}}`
- **Target Market Location:** `{{GEOLOCATION}}`
- **Target LLM Engine:** (ChatGPT, Perplexity, SGE, Claude)

## 1. Technical Triage & Indexing
- [ ] Perform absolute crawl analysis using Screaming Frog or equivalent to parse 404s and redirect chains.
- [ ] Audit Core Web Vitals (LCP, FID, CLS) passing standards across mobile and desktop.
- [ ] Auto-generate and validate canonical tags mapping across `{{COMPANY_URL}}` subdirectories.
- [ ] Update and force-submit `sitemap.xml` via Google Search Console.

## 2. Programmatic On-Page Syntax Standardization
- [ ] Map H1, H2, and H3 hierarchies programmatically aligning with `{{PRIMARY_KEYWORD}}` search intent.
- [ ] Inject LSI (Latent Semantic Indexing) keywords uniformly across meta descriptions, schema markups, and body text.
- [ ] Deploy strict Internal Linking mapping (minimum 3 incoming, 3 outgoing internal links per pillar page).
- [ ] Synthesize URL slugs. Ensure absolute lowercase dash-delimited structures natively.

## 2.5. GEO (Generative Engine Optimization) Readiness
- [ ] Inject 'Citation-Friendly' statistics, quotes, and primary source data into articles to increase LLM 'Information Gain' scores.
- [ ] Implement robust semantic Schema.org JSON-LD markups so LLMs easily parse entity relationships.
- [ ] Format key sections as direct Q&A (Markdown tables or bulleted lists) engineered for AI Overviews (SGE) and Perplexity scraping.

## 3. Backlink Velocity Outreach
- [ ] Identify Top 50 Domain Authority targets currently linking to `{{COMPETITORS}}`.
- [ ] Spin up programmatic mass-outreach sequences offering high-leverage guest assets (Data studies, infographics).
- [ ] Reclaim lost links and unlinked brand mentions.

## 4. Algorithmic QA & Ranking Loops
- [ ] Monitor SERP volatility daily for the top 10 target keywords.
- [ ] Execute bi-weekly content decay audits; refresh articles dropping out of Top 3 ranking bands.

## 5. CRO & Growth Hacking (Organic Viral Loops)
- [ ] Deploy 'Content Upgrades' (Checklists, Templates) gated behind email capture on the Top 5 performing organic pages to capture LTV intent.
- [ ] Embed interactive 'Viral Mechanisms' (Calculators, Quizzes) mapped to the `{{PRIMARY_KEYWORD}}`.
- [ ] Audit organic page readability: ensure the first 100 words leverage the **Curiosity Gap** and **Zeigarnik Effect** to maximize user 'Time on Page' (critical for SEO dwell-time ranking metrics).
