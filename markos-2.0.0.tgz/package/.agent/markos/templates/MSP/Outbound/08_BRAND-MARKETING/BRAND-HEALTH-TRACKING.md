# BRAND-HEALTH-TRACKING.md — Brand Equity Measurement

<!-- markos-token: MSP -->
> [!NOTE] OVERRIDE PATH: Copy this file to .markos-local/MSP/Outbound/08_BRAND-MARKETING/BRAND-HEALTH-TRACKING.md to customize it safely.


```
status      : empty
last_updated: YYYY-MM-DD
```

---

## Brand Health Metrics

| Metric | Measurement Method | Baseline | Target | Cadence |
|--------|------------------|---------|--------|---------|
| Branded search volume | Google Search Console | [FILL] | [FILL] | Monthly |
| Direct traffic | PostHog | [FILL] | [FILL] | Monthly |
| Brand mentions | [Mention.com / Brand24 / Manual] | [FILL] | [FILL] | Monthly |
| Net Promoter Score | Client survey | [FILL] | [FILL] | Quarterly |
| Share of voice | [Tool] | [FILL] | [FILL] | Quarterly |

---

## Quarterly Brand Health Report Template

**Period:** [YYYY-QN]
**Branded search volume:** [FILL] (vs. previous quarter: [FILL])
**Direct traffic:** [FILL] (vs. previous quarter: [FILL])
**Brand sentiment:** [Positive / Neutral / Mixed — based on: FILL]
**Notable mentions:** [FILL]
**Brand health verdict:** [GROWING / STABLE / DECLINING]
**Action required:** [FILL or NONE]
