# MISSION-VISION-VALUES.md — Strategic North Star
<!-- markos-token: MIR -->
> [!NOTE] OVERRIDE PATH: Copy this file to `.markos-local/MIR/Core_Strategy/01_COMPANY/MISSION-VISION-VALUES.md` to customize it safely.

> [!IMPORTANT]
> **AGENT LOGIC**: This is the recursive source for all strategic decisions. `markos-strategist` MUST refer back to these values (Section 3) and principles (Section 4) when resolving multi-agent conflicts or prioritizing roadmap phases.

**Dependencies:** PROJECT (`../00_META/PROJECT.md`), PROFILE (`PROFILE.md`)
**Assigned Agent:** `markos-strategist`
**Linear Project Manager:** `markos-linear-manager`

```
file_purpose  : Define the why, the what, and the how of this business at a strategic level.
                Used to align all marketing messaging and strategic decisions.
status        : empty
last_updated  : YYYY-MM-DD
authoritative : YES for strategic direction
```

> **Instructions for filling this file:** These are not marketing slogans. They are operational declarations. Write them so that any team member or agent could use them to make a decision when in doubt.

---

## 1. Mission Statement

**What we do and for whom, right now:**

> A mission statement is a present-tense declaration of purpose. It answers: "What are we doing today, and for whom?"

```
[FILL — one to two sentences, direct and specific]
```

**How to use this in marketing:**
[FILL — e.g. "Use in About pages, pitch decks, and onboarding materials. Never use as an ad headline."]

---

## 2. Vision Statement

**The future state we are building toward:**

> A vision statement is a future-oriented declaration. It answers: "What world do we want to exist because of our work?"

```
[FILL — one to two sentences, ambitious but specific]
```

**How to use this in marketing:**
[FILL — e.g. "Use in long-form content, founder storytelling, investor-facing materials."]

---

## 3. Core Values

> Values are behavioral commitments, not aspirations. Each one should be specific enough that it helps someone make a hard decision.

**Format:** [Value Name] — [What it means in practice] — [What it looks like when violated]

| Value | What It Means | Violation Example |
|-------|--------------|------------------|
| [Value 1] | [Practical meaning] | [What NOT to do] |
| [Value 2] | [Practical meaning] | [What NOT to do] |
| [Value 3] | [Practical meaning] | [What NOT to do] |
| [Value 4] | [Practical meaning] | [What NOT to do] |

---

## 4. Strategic Principles

> Principles are non-negotiable rules that govern how decisions are made. More specific than values.

| # | Principle | Rationale |
|---|-----------|-----------|
| 1 | [Principle] | [Why this governs decisions here] |
| 2 | [Principle] | [Why this governs decisions here] |
| 3 | [Principle] | [Why this governs decisions here] |

---

## 5. What We Stand Against

> Explicit anti-values. What this business refuses to be or do. These are as important as stated values — they define the edges.

- We do NOT: [FILL]
- We do NOT: [FILL]
- We are NOT the kind of business that: [FILL]

---

## 6. Marketing Alignment

**How the mission/vision/values should show up in marketing:**
[FILL — e.g. "Messaging should reflect radical transparency — we show pricing, we show process, we show results or admit when we don't have them."]

**How they should NOT show up:**
[FILL — e.g. "Do not use values as slogans. Do not claim value alignment without showing evidence."]
