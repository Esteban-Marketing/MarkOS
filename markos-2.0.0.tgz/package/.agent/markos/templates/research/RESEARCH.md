---
token_id: MARKOS-TPL-ANA-01
document_class: TPL
domain: ANA
version: "1.0.0"
status: active
upstream:
  - MARKOS-IDX-000
downstream:
  - MARKOS-AGT-AUD-02  # markos-market-researcher fills this
  - MARKOS-AGT-STR-02  # markos-planner reads this as CONTEXT input
  - MARKOS-AGT-STR-01  # markos-strategist reads this
mir_gate_required: none
---

# RESEARCH.md — Market Research Output Template

<!-- TOKEN: MARKOS-TPL-ANA-01 | CLASS: TPL | DOMAIN: ANA -->
<!-- PURPOSE: Standard output format for market research phases. Every markos-market-researcher and markos-research-phase execution writes to this template. The planner reads RESEARCH.md as a primary input before creating PLAN.md. No research artifact may be consumed by planners without conforming to this schema. -->
<!-- USAGE: Copy to .planning/phases/{N}/RESEARCH.md. Fill all [FILL] fields. [FILL] markers must be gone before planner reads this file. -->
<!-- RULE: Every claim in this document must cite a source. "Competitors use emotional hooks" ✗ — "Competitor A uses emotional hooks — evidence: Meta Ad Library ad copy dated 2026-Q1" ✓ -->

## See Also

| TOKEN_ID | File | Relationship |
|----------|------|--------------|
| MARKOS-AGT-AUD-02 | agents/markos-market-researcher.md | Primary producer of this document |
| MARKOS-SKL-ANA-01 | skills/markos-research-phase/SKILL.md | Skill that invokes market researcher |
| MARKOS-AGT-STR-02 | agents/markos-planner.md | Reads this as key input (RESEARCH.md listed in Inputs) |
| MARKOS-TPL-OPS-04 | templates/context.md | Context.md is produced alongside this in research phases |

---

```yaml
phase: [N — Phase Name]
research_date: [YYYY-MM-DD]
researcher_agent: MARKOS-AGT-AUD-02
reviewed_by: [human name — required before planner reads this]
status: [draft | reviewed | locked]
scope: [one sentence — what marketing question this research answers]
campaign_id: [if applicable]
```

---

## 1. Research Brief

**Question this research answers:**
> [FILL — The specific marketing or strategic question that triggered this research phase. Example: "What messaging angles are competitors in the B2B SaaS onboarding space using in Q1 2026, and which biological triggers dominate?"]

**Scope boundaries:**
- In scope: [FILL]
- Out of scope: [FILL]
- Research method: [web search | public data | ad libraries | community monitoring | platform analytics]

---

## 2. Market Landscape

### 2.1 Market Size & Demand Signals

| Signal | Finding | Source | Date |
|--------|---------|--------|------|
| Market size estimate | [FILL] | [FILL] | [FILL] |
| Growth trend | [FILL] | [FILL] | [FILL] |
| Key demand driver 1 | [FILL] | [FILL] | [FILL] |
| Key demand driver 2 | [FILL] | [FILL] | [FILL] |

### 2.2 Industry Signals (Platform & Algorithm Changes)

| Signal | Type | Impact Level | Source |
|--------|------|-------------|--------|
| [FILL] | [platform change / policy / trend] | [High / Medium / Low] | [FILL] |

---

## 3. Competitive Intelligence

### 3.1 Competitor Campaign Analysis

For each relevant competitor:

```
Competitor: [Name]
Ad Library URL: [FILL or N/A]
Active ads observed: [N] ads
Primary angle: [FILL — what hook/message they lead with]
Biological trigger: [B0N — inferred from hook type]
CTA style: [verb + outcome or verb + feature]
Offer type: [free trial / demo / lead magnet / direct sale]
Landing page headline: [exact text if available]
Messaging gaps: [what they don't address that we could own]
```

### 3.2 Competitive Positioning Map

| Competitor | Core Message | Strength | Vulnerability |
|------------|-------------|----------|--------------|
| [FILL] | [FILL] | [FILL] | [FILL] |

### 3.3 Messaging White Space

> [FILL — What angles, pain points, or audience segments no competitor currently owns? This is the strategic opportunity space.]

---

## 4. Audience Intelligence

### 4.1 ICP Language Signals

Exact language the ICP uses in community discussions:

| Pain Point Phrase | Source | Platform | Date |
|------------------|--------|----------|------|
| "[FILL — exact quote]" | [FILL] | [Reddit/Forum/etc] | [FILL] |
| "[FILL — exact quote]" | [FILL] | [FILL] | [FILL] |

### 4.2 Objections Found in Research

| Objection | Source | Frequency | Current Response in MESSAGING-FRAMEWORK.md |
|-----------|--------|-----------|---------------------------------------------|
| "[FILL]" | [FILL] | [FILL] | [covered / missing] |

### 4.3 New Insights vs. Current AUDIENCES.md

| Field in AUDIENCES.md | Current Value | Research Finding | Action |
|-----------------------|--------------|-----------------|--------|
| `pain_points[]` | [current] | [FILL new insight] | Add / Replace / Confirm |
| `language_patterns[]` | [current] | [FILL] | Add / Replace / Confirm |

---

## 5. Channel Performance Benchmarks

| Channel | Metric | Industry Benchmark | Our Target | Source |
|---------|--------|--------------------|-----------|--------|
| Meta Ads | CPL | [FILL] | [from KPI-FRAMEWORK.md] | [FILL] |
| Google Ads | CVR | [FILL] | [FILL] | [FILL] |
| Email | Open rate | [FILL] | [FILL] | [FILL] |
| LinkedIn | CTR | [FILL] | [FILL] | [FILL] |

---

## 6. Keyword & SEO Signals

| Keyword | Monthly Volume | Difficulty | Intent | Opportunity |
|---------|---------------|------------|--------|-------------|
| [FILL] | [FILL] | [FILL] | [awareness/consideration/decision] | [FILL] |

---

## 7. Key Findings & Planner Directives

> [FILL — 3–5 bullet points. Each bullet is a concrete finding the planner must act on. No abstract observations.]

- **Finding 1:** [Specific, cited finding] → **Planner directive:** [What to build or change in PLAN.md]
- **Finding 2:** [FILL] → **Planner directive:** [FILL]
- **Finding 3:** [FILL] → **Planner directive:** [FILL]

---

## 8. MIR Update Recommendations

Files in the MIR that should be updated based on this research (requires human approval):

| File | Field | Current Value | Recommended Update | Priority |
|------|-------|--------------|-------------------|----------|
| `AUDIENCES.md` | `pain_points[]` | [current] | [FILL] | [P1/P2/P3] |
| `MESSAGING-FRAMEWORK.md` | `objection_responses` | [current] | [FILL] | [FILL] |

**Human must review and approve all MIR update recommendations before they are applied.**

---

## 9. Research Limitations

> [FILL — What data was unavailable, inaccessible, or assumed? Every research limitation must be stated so the planner calibrates confidence correctly.]

---

*Research produced by `MARKOS-AGT-AUD-02`. Status `locked` required before planner reads this file.*
